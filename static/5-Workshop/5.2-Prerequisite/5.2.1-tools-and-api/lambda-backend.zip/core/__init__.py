# Init core module
